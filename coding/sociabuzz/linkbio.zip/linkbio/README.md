file background.html, video.html, gradientstotop.html dan gradientstobottom.html hanyalah sebuah sampel saja.

beberapa panduan

1. jika ingin menambahkan background image pada layar backgrouund please add class bg-image pada body
2. jika ingin menambahkan background linear gradients to top pada layar backgrouund please add class 'bg\_\_to-top' pada body
<!-- bg__to-top -->
3. jika ingin menambahkan background linear gradients to bottom pada layar backgrouund please add class bg\_\_to-bottom pada body
<!-- bg__to-bottom -->

4. jika ingin menambahkan video autoplay please add class bgVideoBody pada body dan tambahkan tag video di dalem body contoh tag video tertera pada file video.html atau akan saya jelaskan di bawah tag videonya

note :

1. untuk gradients jika ingin mengubah derajat gradients secara dinamis ubah saja deg pada kelas bg\_\_to-top atau bg\_\_to-bottom dan gunakan salah satunyaa saja
   <!-- bg__to-top -->
   <!-- bg__to-bottom -->

2. untuk tag video seperti contoh di bawah
   <video
   playsinline
   webkit-playsinline
   autoplay
   loop
   muted
   id="bg-video"
   class="bgVideo"
   poster="https://storage.coverr.co/p/37y2exTgopNa400zQFBVn9YujTboG88Kg"

   > Maaf browsermu tidak mendukung tag video ini

      <source
        src="https://storage.coverr.co/videos/37y2exTgopNa400zQFBVn9YujTboG88Kg?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBJZCI6IkE3OTkzOEYxODJEODQ2NEU3MTJEIiwiaWF0IjoxNjI5OTYwMzE1fQ.Gu_Wixzf1BpmLR0CfUVZJIwvmpaM4fyvOtPcoODSnFs"
        type="video/mp4"
      />
    </video>

   penjelasan tag video poster adlaah gambar awal sebelum video di mulai yang mana di gunakan sebagi cover saja, jika tidak ada poster kosongkan saja poster tersebut

   mohon maaf kode di atas belum sepenuhnya di refactor jadi jika ada kode yang membingungkan bisa di tanyakan ke saya ya mas :v
