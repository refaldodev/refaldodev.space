// code accordion start
var container = document.querySelector(".accordion-container");

container.addEventListener("click", function (e) {
  // e.preventDefault();
  var header = e.target.closest(".accordion-header");
  if (header) {
    // Hide current open
    var headerOpen = document.querySelector(
      ".accordion-item.active .accordion-header"
    );
    if (headerOpen && !headerOpen.isSameNode(header)) {
      headerOpen.closest(".accordion-item").classList.remove("active");
    }

    // Show current clicked
    var item = e.target.closest(".accordion-item");
    item.classList.toggle("active");
  }
});
// end acordion

// tab panel start
var tabbuttons = document.querySelectorAll(".content .content__button button");
var tabpannels = document.querySelectorAll(".content .content__tabpanel");
function showPanel(panelIndex, colorCode) {
  $(".content .content__button button").each(function () {
    // e.preventDefault();
    if ($(this).index() !== panelIndex) {
      $(this).removeAttr("style");
    } else {
      $(this).css({
        borderBottom: "2px solid " + colorCode,
        color: "black",
      });
    }
    // $(this).css({
    //   borderBottom: "2px solid " + colorCode,
    //   color: "black",
    // });
  });
  // tabbuttons[panelIndex].style.borderBottom = `2px solid ${colorCode}`;
  $(tabbuttons[panelIndex]).css("borderbottom", `2px solid ${colorCode}`);
  $(tabbuttons[panelIndex]).css("color", `black`);
  // tabbuttons[panelIndex].style.color = "black";
  $(".content .content__tabpanel").each(function () {
    $(this).hide();
  });
  tabpannels[panelIndex].style.display = "block";
  tabpannels[panelIndex].style.borderBottom = colorCode;
}
showPanel(0, "#e94151");

// tab panel end

// code class add active for logo payment start
var $logo = $(".logo-pembayaran");
var $span = $(".check-active");
$(".logo-pembayaran").each(function () {
  $(this).on("click", function (e) {
    e.preventDefault();
    $logo.removeClass("active");
    $span.removeClass("active");
    $(this).addClass("active");
    $(this).siblings().addClass("active");
  });
});
//code add active for logo payment end

// code change input concurency
var rupiah = document.getElementById("rupiah");
rupiah.addEventListener("keyup", function (e) {
  // tambahkan 'Rp.' pada saat form di ketik
  // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
  rupiah.value = formatRupiah(this.value);
});

/* Fungsi formatRupiah */
function formatRupiah(angka, prefix) {
  var number_string = angka.replace(/[^,\d]/g, "").toString(),
    split = number_string.split(","),
    sisa = split[0].length % 3,
    rupiah = split[0].substr(0, sisa),
    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

  // tambahkan titik jika yang di input sudah menjadi angka ribuan
  if (ribuan) {
    console.log(sisa);
    separator = sisa ? "." : "";
    rupiah += separator + ribuan.join(".");
  }

  rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
  return prefix == undefined ? rupiah : rupiah ? rupiah : "";
}
// code change input concurency  end

//  memberikan pesan browser tidak support pada safari spotify <= 10
// fungsi mendeteksi browser yang digunakan user
function get_browser() {
  var ua = navigator.userAgent,
    tem,
    M =
      ua.match(
        /(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i
      ) || [];
  if (/trident/i.test(M[1])) {
    tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
    return { name: "IE", version: tem[1] || "" };
  }
  if (M[1] === "Chrome") {
    tem = ua.match(/\bOPR|Edge\/(\d+)/);
    if (tem != null) {
      return { name: "Opera", version: tem[1] };
    }
  }
  M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, "-?"];
  if ((tem = ua.match(/version\/(\d+)/i)) != null) {
    M.splice(1, 1, tem[1]);
  }
  return {
    name: M[0],
    version: M[1],
  };
}
var browser = get_browser();

// example
// browser.name = 'Chrome'
// browser.version  = '96'

// cek kondisi untuk browser safaru versi < 11
if (browser.name == "Safari" && browser.version < 11) {
  $(".container-videospotify").append(
    '<div class="music pt-2  text-light my-auto text-error text-center" ><p class="mx-auto text-error__message">The media could not be loaded because the format is not supported by the browser. </p></div>'
  );
}
//  menmberikan pesan browser tidak support pada safari spotify <= 10 end
